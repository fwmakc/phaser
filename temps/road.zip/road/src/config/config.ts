import * as Phaser from 'phaser';
// import { IntroScene } from '#src/scenes/intro/intro.scene';
import { BootScene } from '#src/scenes/boot/boot.scene';
import { GameScene } from '#src/scenes/game/game.scene';
export default undefined;

export const config = {
    // type: Phaser.WEBGL,
    // // backgroundColor: COLORS.SKY,
    // parent: "phaser-runner",
    // antialias: false,
    // // roundPixels: true,

    type: Phaser.AUTO,
    backgroundColor: '#125555',
    pixelArt: true,

    width: 800,
    height: 600, 
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 200 }
        }
    },
    scene: [
        BootScene,
        // IntroScene,
        GameScene
    ]
};
