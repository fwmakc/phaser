import * as Phaser from 'phaser';
import { config } from '#src/config/config';

const game = new Phaser.Game(config);
