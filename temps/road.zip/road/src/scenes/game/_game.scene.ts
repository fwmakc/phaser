import * as Phaser from 'phaser';
import { preload } from '#src/scenes/game/game.preload';
import { create } from '#src/scenes/game/game.create';
import { update } from '#src/scenes/game/game.update';

export default undefined;

export class GameScene extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'GameScene'
        });
    }

    preload ()
    {
        preload(this);
    }

    create ()
    {
        create(this);
    }

    update() {
        update(this);
    }
};
