export default undefined;

export function preload (game) {
    return game;
}
