import { images } from '#src/scenes/intro/intro.images';

export default undefined;

export function preload (game) {
    Object.entries(images).map(([key, value]) => {
        game.load.image(key, value);
        return value;
    });
};
