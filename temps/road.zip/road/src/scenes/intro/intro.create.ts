import { config } from '#src/config/config';

export default undefined;

export function create (game) {
    const logo = game.add.image(config.width / 2, config.height / 2, 'logo');

    game.tweens.add({
        targets: logo,
        duration: 5000,
        scale: {
            getStart: () => 5,
            getEnd: () => 0.5
        },
        alpha: {
            getStart: () => 0,
            getEnd: () => 1
        },
        ease: 'Sine.inOut',
        // yoyo: true,
        // repeat: -1
        onComplete(e) {
            console.log(e);
        }
    });

    game.tweens.add({
        targets: logo,
        delay: 5000,
        duration: 1000,
        y: logo.height,
        ease: 'Sine.inOut',
    });
};
