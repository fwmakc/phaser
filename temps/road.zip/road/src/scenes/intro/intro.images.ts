export default undefined;

export const images = {
    logo: 'assets/phaser3-logo.png',
};
