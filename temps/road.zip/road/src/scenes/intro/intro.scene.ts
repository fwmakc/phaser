import * as Phaser from 'phaser';
import { preload } from '#src/scenes/intro/intro.preload';
import { create } from '#src/scenes/intro/intro.create';
import { update } from '#src/scenes/intro/intro.update';

export default undefined;

export class IntroScene extends Phaser.Scene
{
    constructor ()
    {
        super();
    }

    preload ()
    {
        preload(this);
    }

    create ()
    {
        create(this);
    }

    update() {
        update(this);
    }
};
