import * as Phaser from 'phaser';
import { preload } from '#src/scenes/boot/boot.preload';
import { create } from '#src/scenes/boot/boot.create';
import { update } from '#src/scenes/boot/boot.update';

export default undefined;

export class BootScene extends Phaser.Scene
{
    constructor ()
    {
        super({
            key: 'BootScene'
        });
    }

    preload ()
    {
        preload(this);
    }

    create ()
    {
        create(this);
    }

    update() {
        update(this);
    }
}
