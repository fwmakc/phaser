export default undefined;

export function create (game) {
    return game;
};
