export default undefined;

export const images = {
    bg: 'assets/game/background.png',
    car: 'assets/game/carSingle.png',
    billboard: 'assets/game/billboard.png',
};
