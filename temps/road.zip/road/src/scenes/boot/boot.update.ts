export default undefined;

export function update (game) {
    return game;
};
