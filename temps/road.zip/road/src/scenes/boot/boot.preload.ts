import { images } from '#src/scenes/boot/boot.images';

export default undefined;

export function preload (game) {
    const progress = game.add.graphics();

    // Register a load progress event to show a load bar
    game.load.on('progress', (value) => {
        progress.clear();
        progress.fillStyle(0xffffff, 1);
        progress.fillRect(0, game.sys.game.config.height / 2, game.sys.game.config.width * value, 60);
    });

    // Register a load complete event to launch the title screen when all files are loaded
    game.load.on('complete', () => {
        // prepare all animations, defined in a separate file
        progress.destroy();
        game.scene.start('GameScene');
    });

    Object.entries(images).map(([key, value]) => {
        game.load.image(key, value);
        return value;
    });
};
